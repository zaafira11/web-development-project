var data= {
    chatinit:{
        title: ["Hello <span class='emoji'> &#128075;</span>","How can I help you?"],
        options: ["Services 🛠️","Solutions 🔑","Book a call 📞","Contact IT Helpdesk 📠"]
    },
    services: {
        title:["Please select Services"],
        options:['Password Reset','Meeting Room Book','System Issue','Ticketing Link'],
        url : {
            //link:['#','#','#','https://synergyprod1.service-now.com/renault_worldwide?id=create_incident&sys_id=05074a0fdb63fb008de67b47f49619cf']
        }
    },
    password:{
        title:["Reset your password"],
        options:[],
        url:{

        }
    },
    meeting:{
        title:["Meeting room"],
        options:[],
        url:{

        }

    },
    system:{
        title:["System Issue"],
        options:[],
        url:{

        }

    },
    ticketing:{
        title:["Link"],
        options:['https://synergyprod1.service-now.com/renault_worldwide?id=create_incident&sys_id=05074a0fdb63fb008de67b47f49619cf'],
        url:{
            link:['https://synergyprod1.service-now.com/renault_worldwide?id=create_incident&sys_id=05074a0fdb63fb008de67b47f49619cf']

        }

    },
    
    solutions: {
        title:["Welcome to  help zone ","Here is some of the solutions"],
        options:[],
        url:{

        }
    },
    book: {
        title:["Thanks for your response","Please select one of the below options to proceed further"],
        options:[],
        url : {
            
        }
    },
    contact:{
        title: ["These are some contacts of IT helpdesk"],
        options: ["Helpdesk Common Number", "Network1 Maintenance Common Number", "Network Operation Common Number","Escalations","Print Common(z033681)"],
        numbers: ["4471699000 ", "9629348237", "4471699005"], // Add phone numbers here
        url: {
            
        }
    },
    helpdesk: {
        title: ["Here is the Helpdesk Common Number"],
        options: ["4471699000"],
        url: {
           
        }
    },
    network1: {
        title: ["Here is the Network Maintenance Common Number"],
        options: ["9629348237"],
        url: {
            
        }
    },
    network: {
        title: ["Here is the Network Operation Common Number"],
        options: ["4471699005"],
        url: {
            
        }
    },
    escalations: {
        title: ["Here are some Escalations"],
        options: ["Escalation1 IPN z037538","Escalation2 IPN z009418"],
        url: {
                
        }
    },
    escalation1: {
        title: ["Here is Escalation1 MailId"],
        options: ["vincentabishek.doss-extern@rnaipl.com"],
        url: {
                  
        }
    },
    escalation2: {
        title: ["Here is Escalation2 MailId"],
        options: ["kumar.pazhani@rnaipl.com"],
        url: {
                 
        }
    },
    print: {
        title: ["Here is Print common (z033681) MailId"],
        options: ["common.print@rnaipl.com"],
        url: {
                 
        }
    },
}

document.getElementById("init").addEventListener("click",showChatBot);
var cbot= document.getElementById("chat-box");

var len1= data.chatinit.title.length;

function showChatBot(){
    console.log(this.innerText);
    if(this.innerHTML=='<img src="chat-bot (2).png">'){
        document.getElementById('test').style.display='block';
        document.getElementById('init').innerHTML='<img src="artificial-intelligence.png">';
        initChat();
    }
    else{
        location.reload();
    }
}

function initChat(){
    j=0;
    cbot.innerHTML='';
    for(var i=0;i<len1;i++){
        setTimeout(handleChat,(i*500));
    }
    setTimeout(function(){
        showOptions(data.chatinit.options)
    },((len1+1)*500))
}
function goBack(){
    j=0;
    cbot.innerHTML='';
    for(var i=0;i>len1;i--){
        setTimeout(handleChat,(i*500));
    }
    setTimeout(function(){
        showOptions(data.chatinit.options)
    },((len1+1)*500))
}


var j=0;
function handleChat(){
    console.log(j);
    var elm= document.createElement("p");
    elm.innerHTML= data.chatinit.title[j];
    elm.setAttribute("class","msg");
    cbot.appendChild(elm);
    j++;
    handleScroll();
}


function showOptions(options){
    for(var i=0;i<options.length;i++){
        var opt= document.createElement("span");
        var inp= '<div>'+options[i]+'</div>';
        opt.innerHTML=inp;
        opt.setAttribute("class","opt");
        opt.addEventListener("click", handleOpt);
        cbot.appendChild(opt);
        handleScroll();
    }
}

function handleOpt(){
    console.log(this);
    var str= this.innerText;
    var textArr= str.split(" ");
    var findText= textArr[0];
    
    document.querySelectorAll(".opt").forEach(el=>{
        el.remove();
    })
    var elm= document.createElement("p");
    elm.setAttribute("class","test");
    var sp= '<span class="rep">'+this.innerText+'</span>';
    elm.innerHTML= sp;
    cbot.appendChild(elm);
    console.log(findText.toLowerCase());
    var tempObj= data[findText.toLowerCase()];
    handleResults(tempObj.title,tempObj.options,tempObj.url);
}

function handleDelay(title){
    var elm= document.createElement("p");
        elm.innerHTML= title;
        elm.setAttribute("class","msg");
        cbot.appendChild(elm);
}
function handleResults(title,options,url){
    for(let i=0;i<title.length;i++){
        setTimeout(function(){
            handleDelay(title[i]);
        },i*500)
        
    }


    const isObjectEmpty= (url)=>{
        return JSON.stringify(url)=== "{}";
    }

    if(isObjectEmpty(url)==true){
        console.log("having more options");
        setTimeout(function(){
            showOptions(options);
        },title.length*500)
        
    }
    else{
        console.log("end result");
        setTimeout(function(){
            handleOptions(options,url);
        },title.length*500)
        
    }
}

function handleOptions(options,url){
    for(var i=0;i<options.length;i++){
        var opt= document.createElement("span");
        var inp= '<a class="m-link" href="'+url.link[i]+'">'+options[i]+'</a>';
        opt.innerHTML=inp;
        opt.setAttribute("class","opt");
        cbot.appendChild(opt);
    }
    var opt= document.createElement("span");
    /*var inp= '<a class="m-link" href="'+url.more+'">'+'See more</a>';

    const isObjectEmpty= (url)=>{
        return JSON.stringify(url)=== "{}";
    }*/

    console.log(isObjectEmpty(url));
    console.log(url);
    opt.innerHTML=inp;
    opt.setAttribute("class","opt link");
    cbot.appendChild(opt);
    handleScroll();
}

function handleScroll(){
    var elem= document.getElementById('chat-box');
    elem.scrollTop= elem.scrollHeight;
}

